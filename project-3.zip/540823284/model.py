import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder, OrdinalEncoder, KBinsDiscretizer
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectFromModel
from sklearn.model_selection import GridSearchCV
from sklearn.naive_bayes import CategoricalNB
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

FILENAME = "ObesityDataSet_raw_and_data_sinthetic.csv"
SEED = 42

pd.set_option("future.no_silent_downcasting", True)

data = pd.read_csv(FILENAME)
duplicate_indexes = data[data.duplicated()].index

def evaluateModel(model, X, y_true, model_name, y_labels):
	y_pred_proba = model.predict_proba(X)
	y_pred = model.predict(X)
	print("top_k_accuracy_score", metrics.top_k_accuracy_score(y_true, y_pred_proba))
	print("Confusion matrix:", metrics.confusion_matrix(y_true, y_pred))
	disp = metrics.ConfusionMatrixDisplay.from_estimator(model,
														 X,
														 y_true,
														 display_labels=y_labels,
														 xticks_rotation="vertical",
														 )
	disp.plot()
	plt.xticks(rotation=90)
	plt.title(model_name)
	plt.tight_layout()
	plt.savefig(model_name + ".png", dpi=300)

#######################
# Feature engineering #
#######################

# Label encoding
gender_encoder = OrdinalEncoder(dtype=np.int8)
data["Gender"] = gender_encoder.fit_transform(data[["Gender"]])

# Questions that only have yes or no answers
columns_binary = ["family_history_with_overweight",
				"FAVC", 
				"SMOKE",
				"SCC"]
bin_encoder = OrdinalEncoder(categories=[["no", "yes"]],
							 dtype=np.int8)
for column in columns_binary:
	data[column] = bin_encoder.fit_transform(data[[column]])

# Ordinal questions
columns_frequency = ["CAEC", "CALC"]
ord_encoder = OrdinalEncoder(categories=[["no", "Sometimes", "Frequently", "Always"]],
							 dtype=np.int8)
for column in columns_frequency:
	data[column] = ord_encoder.fit_transform(data[[column]])

# Removed as Unnecessary. However if not, need to only fit from training data
# age_scaler = MinMaxScaler()
# data["Age"] = age_scaler.fit_transform(data[["Age"]])

# Numeric values past age are actually ordinal questions, with
# synthetic data as floating point. Use equal size bins.
for column in data.columns[4:]:
	if data[column].dtype == np.float64:
		n_categories = int(data[column].max() - data[column].min() + 1)
		bins = KBinsDiscretizer(n_bins=n_categories, encode="ordinal", strategy="uniform")
		data[column] = bins.fit_transform(data[[column]])
		data[column] = data[column].convert_dtypes()

# Obesity categories to ordinal
obesity_encoder = OrdinalEncoder(categories=[['Insufficient_Weight',
											'Normal_Weight',
											'Overweight_Level_I',
											'Overweight_Level_II',
											'Obesity_Type_I',
											'Obesity_Type_II',
											'Obesity_Type_III']],
							 dtype=np.int8)
data["NObeyesdad"] = obesity_encoder.fit_transform(data[["NObeyesdad"]])
		
# One=hot encoding of transport type, as it lacks natural ordering
# towardsdatascience.com/categorical-encoding-using-label-encoding-and-one-hot-encoder-911ef77fb5bd
oh_encoder = OneHotEncoder(dtype=np.int8, sparse_output=False)
transport_data = pd.DataFrame(oh_encoder.fit_transform(data[["MTRANS"]]))
transport_data.columns = list(oh_encoder.categories_[0])
data = data.join(transport_data)

# Reorder columns so obesity is last
column_order = list(data.columns)[:-1 - len(transport_data.columns)]
column_order.extend(list(transport_data.columns))
column_order.append("NObeyesdad")
data = data[column_order]

# Drop MTRANS, now represented by one-hot encoding
data.drop(columns="MTRANS", inplace=True)

#######################
#    Data Splitting   #
#######################
column_names = list(data.columns)
input_names = column_names[:-1]
# Exclude variables that are used in BMI calculation.
input_names.remove("Height")
input_names.remove("Weight")
target_name = column_names[-1]

X = data[input_names]        # slice dataFrame to extract input variables
y = data[target_name]        # slice dataFrame to extract target variable
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=SEED)
# Use validate when choosing models to use/tuning hyperparameters
X_train, X_validate, y_train, y_validate = train_test_split(X_train, y_train, test_size=0.1, random_state=SEED)

# Only removing duplicates now to ensure same data is in the test set as others
for df in [X_train, X_test, X_validate, y_train, y_test, y_validate]:
	df.drop(index=duplicate_indexes, errors="ignore", inplace=True)

#######################
#  1. Model training  #
#######################

# First model: Random forest with Grid search of hyperparameters
forest_clf = RandomForestClassifier(random_state=SEED)
param_grid = {
	"n_estimators": [50, 100, 200, 800],
	"max_depth": [3, 4, 5, 6],
	"max_samples": [0.1, 0.3, 0.5, 0.6, 0.8, 0.9],
}
grid_clf = GridSearchCV(forest_clf,
					  param_grid).fit(X_train, y_train)

#######################
# 1. Model evaluation #
#######################

# Print model type
print("Grid search on a Random Forest Classifier")
print("Best hyperparameters", grid_clf.best_params_)
print("Feature importance")
grid_feature_importance = pd.DataFrame(grid_clf.best_estimator_.feature_importances_,
									   index=input_names)
print(grid_feature_importance.sort_values(0, ascending=False))

evaluateModel(grid_clf, X_validate, y_validate, "Random Forest Model Confusion Matrix (Validation)", obesity_encoder.categories[0])
evaluateModel(grid_clf, X_test, y_test, "Random Forest Model Confusion Matrix", obesity_encoder.categories[0])

#######################
#  2. Model training  #
#######################

# Second model: Categorical Naive Bayes
# Remove Age, which is not categorical
X_train.drop(columns="Age", inplace=True)
X_validate.drop(columns="Age", inplace=True)
X_test.drop(columns="Age", inplace=True)

alpha_search = {
	"alpha": [(p+1)/10.0 for p in range(9)]
}

category_count = [len(data[name].unique()) for name in input_names if name != "Age"]

bayes_clf = GridSearchCV(CategoricalNB(min_categories=category_count),
						alpha_search).fit(X_train, y_train)

#######################
# 2. Model evaluation #
#######################

print("Grid search on a Categorical Naive Bayes Classifier")
print("Best hyperparameter", bayes_clf.best_params_)
evaluateModel(bayes_clf, X_validate, y_validate, "Naive Bayes Model Confusion Matrix (Validation)", obesity_encoder.categories[0])
evaluateModel(bayes_clf, X_test, y_test, "Naive Bayes Model Confusion Matrix", obesity_encoder.categories[0])