import pandas as pd
from pandas.api.types import is_numeric_dtype
import sys

def dataQualityCheck(data):
	# Quick way to check if any null values: https://stackoverflow.com/a/29530601
	if data.isnull().values.any():
		print("Warning: null values present", file=sys.stderr)

	duplicates = data[data.duplicated()]
	if not duplicates.empty:
		print(f"Warning: {len(duplicates)} duplicates found.", file=sys.stderr)
		for index, row in zip(duplicates.index, duplicates.values):
			print(index, row)

def printSummary(data):
	for name in data:
		if not is_numeric_dtype(data[name]):
			all_values = data[name].unique()
			print(name + ": " + all_values)
		else:
			print(name)
			print(data[name].describe())

if __name__ == "__main__":
	FILENAME = "ObesityDataSet_raw_and_data_sinthetic.csv"
	data = pd.read_csv(FILENAME)
	dataQualityCheck(data)
	printSummary(data)