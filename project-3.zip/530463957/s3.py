import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import BaggingClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, top_k_accuracy_score, ConfusionMatrixDisplay
import numpy as np
import matplotlib.pyplot as plt

# Load the dataset
data = pd.read_csv('ObesityDataSet_raw_and_data_sinthetic.csv')

# Remove 'Weight' and 'Height' columns as they are used to calculate the predictor variable
data = data.drop(['Weight', 'Height'], axis=1)

# Label Encoding for categorical features
label = {}
categorical_columns = ['Gender', 'family_history_with_overweight', 'FAVC', 'CAEC', 'SMOKE', 'SCC', 'CALC', 'MTRANS']

for column in categorical_columns:
    label[column] = LabelEncoder()
    data.loc[:, column] = label[column].fit_transform(data[column])

# Encode the target variable 'NObeyesdad' as discrete labels
label['NObeyesdad'] = LabelEncoder()
data['NObeyesdad'] = label['NObeyesdad'].fit_transform(data['NObeyesdad'])

# Normalize 'Age' column
scaler = StandardScaler()
data['Age'] = scaler.fit_transform(data[['Age']])

# Define X and y
X = data.drop('NObeyesdad', axis=1)
y = data['NObeyesdad']  # encoded as integers

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

# Logistic Regression
logreg = LogisticRegression(max_iter=2000, solver='liblinear') 
logreg.fit(X_train, y_train)

# Cross-validation for Logistic Regression
logreg_cv_scores = cross_val_score(logreg, X, y, cv=5, scoring='accuracy')
logreg_cv_mean = logreg_cv_scores.mean()

# Bagging Classifier (Ensemble)
bagging = BaggingClassifier(n_estimators=50, random_state=42)
bagging.fit(X_train, y_train)

# Cross-validation for Bagging Classifier
bagging_cv_scores = cross_val_score(bagging, X, y, cv=5, scoring='accuracy')
bagging_cv_mean = bagging_cv_scores.mean()

# Predict and evaluate
y_pred_logreg = logreg.predict(X_test)
y_pred_bagging = bagging.predict(X_test)

accuracy_logreg = accuracy_score(y_test, y_pred_logreg)
confusion_logreg = confusion_matrix(y_test, y_pred_logreg)

accuracy_bagging = accuracy_score(y_test, y_pred_bagging)
confusion_bagging = confusion_matrix(y_test, y_pred_bagging)

# Top K accuracy for both models
unique_labels = np.unique(y_train)

top_k_logreg = top_k_accuracy_score(y_test, logreg.predict_proba(X_test), k=2, labels=unique_labels)
top_k_bagging = top_k_accuracy_score(y_test, bagging.predict_proba(X_test), k=2, labels=unique_labels)

# Output the results
print(f"Logistic Regression Accuracy (Test): {accuracy_logreg}")
print(f"Logistic Regression Confusion Matrix (Test):\n{confusion_logreg}")
print(f"Logistic Regression Top 2 Accuracy (Test): {top_k_logreg}")
print(f"Logistic Regression Cross-Validation Mean Accuracy: {logreg_cv_mean}")
print(f"Logistic Regression Cross-Validation Scores: {logreg_cv_scores}\n")

print(f"Bagging Classifier Accuracy (Test): {accuracy_bagging}")
print(f"Bagging Classifier Confusion Matrix (Test):\n{confusion_bagging}")
print(f"Bagging Classifier Top 2 Accuracy (Test): {top_k_bagging}")
print(f"Bagging Classifier Cross-Validation Mean Accuracy: {bagging_cv_mean}")
print(f"Bagging Classifier Cross-Validation Scores: {bagging_cv_scores}")

# Visualize confusion matrices separately and save the plots

# Logistic Regression Confusion Matrix
plt.figure(figsize=(8, 6))
disp_logreg = ConfusionMatrixDisplay(confusion_matrix=confusion_logreg, display_labels=label['NObeyesdad'].classes_)
disp_logreg.plot(cmap=plt.cm.Blues, values_format='d')
plt.title('Logistic Regression Confusion Matrix')
plt.xticks(rotation=45, ha='right') 
plt.subplots_adjust(left=0.1, right=1, top = 0.9, bottom = 0.2) 
plt.savefig('logistic.png') 
plt.show()

# Bagging Classifier Confusion Matrix
plt.figure(figsize=(8, 6))
disp_bagging = ConfusionMatrixDisplay(confusion_matrix=confusion_bagging, display_labels=label['NObeyesdad'].classes_)
disp_bagging.plot(cmap=plt.cm.Blues, values_format='d')
plt.title('Bagging Classifier Confusion Matrix')
plt.xticks(rotation=45, ha='right') 
plt.subplots_adjust(left=0.1, right=1, top = 0.9, bottom = 0.2)
plt.savefig('bagging.png') 
plt.show()
