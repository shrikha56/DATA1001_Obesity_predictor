import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder
import xgboost as xgb
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report, top_k_accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
df = pd.read_csv('/Users/zhougary/Desktop/obs1.csv')

# Selecting relevant columns for analysis
columns_to_use = [
    'Age', 'Gender', 'family_history_with_overweight', 'FAVC', 'FCVC', 'NCP', 'CAEC', 'SMOKE',
    'CH2O', 'SCC', 'FAF', 'TUE', 'CALC', 'MTRANS', 'NObeyesdad'
]

# Extracting the relevant data
df = df[columns_to_use].copy()

# Rename columns for easier handling
df.columns = ['Age', 'Gender', 'FamilyHistory', 'FAVC', 'FCVC', 'NCP', 'CAEC', 'Smoke',
              'CH2O', 'SCC', 'FAF', 'TUE', 'Calc', 'Transport', 'Obesity']

# Encoding categorical variables
le_gender = LabelEncoder()
df['Gender'] = le_gender.fit_transform(df['Gender'])

le_family = LabelEncoder()
df['FamilyHistory'] = le_family.fit_transform(df['FamilyHistory'])

le_favc = LabelEncoder()
df['FAVC'] = le_favc.fit_transform(df['FAVC'])

le_caec = LabelEncoder()
df['CAEC'] = le_caec.fit_transform(df['CAEC'])

le_smoke = LabelEncoder()
df['Smoke'] = le_smoke.fit_transform(df['Smoke'])

le_scc = LabelEncoder()
df['SCC'] = le_scc.fit_transform(df['SCC'])

le_calc = LabelEncoder()
df['Calc'] = le_calc.fit_transform(df['Calc'])

le_transport = LabelEncoder()
df['Transport'] = le_transport.fit_transform(df['Transport'])

le_obesity = LabelEncoder()
df['Obesity'] = le_obesity.fit_transform(df['Obesity'])

# Splitting data into features and target
X = df.drop('Obesity', axis=1)
y = df['Obesity']

# Splitting into training and testing datasets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

# Normalizing the features using Min-Max normalization
scaler = MinMaxScaler()
X_train_normalized = scaler.fit_transform(X_train)
X_test_normalized = scaler.transform(X_test)

# Standardizing the features
scaler_standard = StandardScaler()
X_train_scaled = scaler_standard.fit_transform(X_train_normalized)
X_test_scaled = scaler_standard.transform(X_test_normalized)

# Building the XGBoost model
xgboost_model = xgb.XGBClassifier(objective='multi:softmax', num_class=len(df['Obesity'].unique()), n_estimators=50, random_state=42)
xgboost_model.fit(X_train_scaled, y_train)
y_pred_xgb = xgboost_model.predict(X_test_scaled)

# Evaluating the XGBoost model
accuracy_xgb = accuracy_score(y_test, y_pred_xgb)
report_xgb = classification_report(y_test, y_pred_xgb)

# XGBoost Top-3 Accuracy
y_proba_xgb = xgboost_model.predict_proba(X_test_scaled)
top3_accuracy_xgb = top_k_accuracy_score(y_test, y_proba_xgb, k=2)

# Building the k-NN model
knn_model = KNeighborsClassifier(n_neighbors=5)
knn_model.fit(X_train_scaled, y_train)
y_pred_knn = knn_model.predict(X_test_scaled)

# Evaluating the k-NN model
accuracy_knn = accuracy_score(y_test, y_pred_knn)
report_knn = classification_report(y_test, y_pred_knn)

# k-NN Top-3 Accuracy
y_proba_knn = knn_model.predict_proba(X_test_scaled)
top3_accuracy_knn = top_k_accuracy_score(y_test, y_proba_knn, k=2)

# Outputting results
print("XGBoost Accuracy:", accuracy_xgb)
print("XGBoost Classification Report:\n", report_xgb)
print("XGBoost Top-3 Accuracy:", top3_accuracy_xgb)

print("k-NN Accuracy:", accuracy_knn)
print("k-NN Classification Report:\n", report_knn)
print("k-NN Top-3 Accuracy:", top3_accuracy_knn)

# Function to plot confusion matrix
def plot_confusion_matrix(y_true, y_pred, title):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False)
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.title(title)
    plt.show()

# Plotting confusion matrix for XGBoost model
print("Confusion Matrix for XGBoost Model")
plot_confusion_matrix(y_test, y_pred_xgb, title="XGBoost Confusion Matrix")

# Plotting confusion matrix for k-NN model
print("Confusion Matrix for k-NN Model")
plot_confusion_matrix(y_test, y_pred_knn, title="k-NN Confusion Matrix")
