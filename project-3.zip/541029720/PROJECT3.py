#import the necessary libraries 
import numpy as np 
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from collections import Counter
from sklearn.metrics import top_k_accuracy_score, confusion_matrix, accuracy_score
from sklearn.svm import SVC
#define the file path for the csv file
file_path = '/Users/shrikha/Desktop/project3/ObesityDataSet_raw_and_data_sinthetic.csv'
#read the file path
df = pd.read_csv(file_path)
#remove the column for weight and height from the data frame
df.drop('Height', axis=1, inplace=True)
df.drop('Weight', axis=1, inplace=True)
#print the first 5 values from each column
print(df.head(n=5))

from sklearn import preprocessing 
#initialise a dictionary to hold the encoding for the categorical columns
label_encoders = {}
categorical_columns = ['NObeyesdad', 'Gender', 'family_history_with_overweight', 'FAVC',
                       'CAEC', 'SMOKE', 'SCC', 'CALC', 'MTRANS']

#loop through the columns, create a label encoder and transform the columns
for column in categorical_columns:
    label_encoders[column] = preprocessing.LabelEncoder()
    df[column] = label_encoders[column].fit_transform(df[column])

#define the feature and target variables
X = df.drop(columns=['NObeyesdad'])  
y = df['NObeyesdad']
#split the dataset into training and testing set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)
print(f"Training set shape: {X_train.shape}, {y_train.shape}")
print(f"Testing set shape: {X_test.shape}, {y_test.shape}")
from sklearn.preprocessing import StandardScaler
#standardise the feature data
scaler = StandardScaler()
scaler.fit(X_train) 
#apply the scaler to the data
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)
#initialise and train the MLPClassifier
from sklearn.neural_network import MLPClassifier
model = MLPClassifier(hidden_layer_sizes =(10,10,10), max_iter = 1000)
model.fit(X_train, y_train.values.ravel())

#make predictions with the model
predictions = model.predict(X_test)
#print the predictions
print(predictions)
#decode the encoded labels
decoded_predictions = label_encoders['NObeyesdad'].inverse_transform(predictions)
print("Decoded Predictions:", decoded_predictions.tolist())
#count the number of time each label occurs
prediction_counts = Counter(decoded_predictions)
print("Count of Predictions:", prediction_counts)
#use top k accuracy score and confusion matrix to evaluate the model's performance
#print the results
print("MLP Confusion Matrix:\n", confusion_matrix(y_test, predictions))
mlp_probabilities = model.predict_proba(X_test)
# Calculate the top-k accuracy score using the predicted probabilities
accuracy = top_k_accuracy_score(y_test, mlp_probabilities, k=2) 
print("MLP Top K accuracy Score:", accuracy)
mlp_accurary_score = accuracy_score(y_test, predictions)
print(f"Accuracy score:{mlp_accurary_score}")
#create a linear svm model
svm_model = SVC(kernel='linear',probability=True)  
#train the data
svm_model.fit(X_train, y_train)
#make predictions with the model
svm_predictions = svm_model.predict(X_test)
print(svm_predictions)
#decode the encoded labels
decoded_svm_predictions = label_encoders['NObeyesdad'].inverse_transform(svm_predictions)
print("SVM Decoded Predictions:", decoded_svm_predictions.tolist())
#count the number of time each label occurs
svm_prediction_counts = Counter(decoded_svm_predictions)
print("SVM Count of Predictions:", svm_prediction_counts)
#use top k accuracy score and confusion matrix to evaluate the model's performance
#print the results
print("SVM Confusion Matrix:\n", confusion_matrix(y_test, svm_predictions))
svm_probabilities = svm_model.predict_proba(X_test)  
svm_accuracy = top_k_accuracy_score(y_test, svm_probabilities, k=2)
svm_accuracy_score = accuracy_score(y_test, svm_predictions)
print("SVM Top K accuracy Score:", svm_accuracy)
print(f"Accuracy score:{svm_accuracy_score}")